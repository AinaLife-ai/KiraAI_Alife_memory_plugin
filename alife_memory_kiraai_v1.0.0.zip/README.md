# Alife Memory for KiraAI

受 Alife 4.2.3 MemoryService 启发，专为 KiraAI 2.33.1+ 设计的长期记忆插件。

---

## 核心特性

### 三重触发异步压缩
- 对话完成后自动记录，**不阻塞**主对话流程
- 三种触发模式可选，任一达到即压缩：
  - **轮数**（默认 10 轮）
  - **Token 估算**（默认 10000）
  - **消息数**（默认 50 条）
- 后台异步压缩 Worker，多会话并行
- 压缩失败不影响原始消息

### 严格分层合并
- 原始轮次 → L1 摘要 → L2 摘要 → … → Ln 摘要
- 同层严格按时间窗口分组，不交叉不重叠
- 合并后旧版本标记为 `stale`，不物理删除
- 源批次指纹去重，同一批消息不会重复压缩

### 跨来源关联检索
- 默认 `linked` 模式，不隔离私聊/群聊/用户
- 同一事实跨不同来源自动合并，保留全部来源引用
- 支持 `session`（当前会话）、`linked`（关联）、`global`（全局）三档
- 综合排序：FTS5 关键词 + 可选向量 + 时间衰减 + 层级 + 来源关联

### 被动召回
- 首次检测到新用户 ID 时，自动召回该用户的相关记忆
- 内容匹配相关记忆自动注入

### 记忆修正与审计
- 即时修正生成新版本，旧版本保留为 `superseded` 审计链
- 后台反思自动检查新证据与旧记忆冲突
- 仅高置信度（≥0.86）结构化 JSON 输出才执行修改
- 低置信度或证据不足不操作

### 会话隔离与还原
- 每条记忆保留原始消息 ID、来源会话、用户、时间戳和轮次号
- 可追溯到原始对话轮次

### 缓存友好注入
- 记忆注入 `memory` 段，`persist=False`，不破坏 System Prompt 前缀缓存
- 每条注入有 Token 预算和条数预算双重限制
- 措辞明确"仅供参考，新证据优先"，让 LLM 重视但不被淹没

### 热配置与 WebUI
- 所有配置项支持热修改，即时生效
- 原子写回配置文件，异常不会清空配置
- 完整 WebUI 侧边栏：总览、记忆管理、检索、任务、配置

---

## 安装方法

将 `alife_memory_kiraai_v1.0.0.zip` 解压到 KiraAI 的 `data/plugins/alife_memory/` 目录，然后在 KiraAI WebUI 中启用插件。

数据库文件自动创建在插件数据目录下的 `memory.sqlite3`。

---

## 配置项说明

### 记忆总控
| 参数 | 默认值 | 说明 |
|------|--------|------|
| enabled | true | 启用记忆系统 |
| capture_enabled | true | 自动记录对话 |
| auto_inject | true | 自动注入相关记忆 |
| passive_recall | true | 被动召回新用户记忆 |
| max_injected_tokens | 900 | 注入 Token 预算上限 |
| max_injected_items | 6 | 注入记忆条数上限 |

### 三重触发压缩
| 参数 | 默认值 | 说明 |
|------|--------|------|
| trigger_mode | either | 触发模式：rounds / tokens / messages / either |
| round_threshold | 10 | 对话轮数阈值 |
| token_threshold | 10000 | 估算 Token 阈值 |
| message_threshold | 50 | 原始消息条数阈值 |

### 压缩与分层
| 参数 | 默认值 | 说明 |
|------|--------|------|
| compress_model | — | 压缩模型，留空用默认 |
| batch_size | 10 | 每批压缩的消息数 |
| level_group_size | 4 | 同层合并数量 |
| max_level | 5 | 最大压缩层级 |
| min_chars | 80 | 最小压缩字符数 |

### 检索与注入
| 参数 | 默认值 | 说明 |
|------|--------|------|
| semantic_enabled | true | 启用语义向量 |
| search_scope | linked | 默认检索范围 |
| cross_user_enabled | true | 允许跨用户关联 |
| top_k | 5 | 默认结果数 |
| recency_half_life_days | 45 | 时间衰减半衰期 |
| inject_level_max | 12 | 注入最高层级 |

### 后台反思
| 参数 | 默认值 | 说明 |
|------|--------|------|
| enabled | true | 启用后台审校 |
| reflect_model | — | 审校模型，留空用压缩模型 |
| interval_seconds | 1800 | 审校间隔（秒） |
| max_items | 4 | 每次审校记忆数 |

---

## LLM 工具

插件注册 4 个工具供 AI 调用：

- **remember_fact** — 主动记录事实
- **search_long_term_memory** — 检索长期记忆
- **correct_long_term_memory** — 修正记忆
- **forget_long_term_memory** — 删除记忆

---

## 安全与一致性

- 压缩失败：原始消息不变，下次重试
- 轮次重复：`event_id` 去重，不重复写入
- 压缩重复：源批次指纹去重，不会生成重复摘要
- 修正安全：旧版本标记为 `superseded`，保留审计链
- 反思安全：仅结构化 JSON + 置信度 ≥0.86 才执行
- 配置安全：深合并 + 原子替换，异常不破坏配置
- 无 embedding 时：自动降级为 FTS5 + LIKE 检索
- 失败回调：worker 异常不影响其他会话

---

## 技术架构

```
捕获: @on.llm_response → 逐条保存原始消息 (user_id + turn_no)
         ↓
触发: 轮数 / Token / 消息数 任一达到 → 后台压缩
         ↓
压缩: 模型生成结构化 JSON → 源批次指纹去重 → 写入记忆表
         ↓
注入: @on.llm_request → FTS5 检索 → Token+条数预算 → memory 段注入
         ↓
反思: 后台循环 → 比较新证据与旧记忆 → 高置信度才修改
```

## 版本

v1.2.0 — 三重触发压缩、被动召回、WebUI 全按钮化、记忆类型纪律、主动与自动精准跨维度检索、绝对日期转换、自动归档